This is simple/shitty JavaScript addon for FireFox, to add keyboard navigation to www.youtube.com

Keybinds are litteraly default js event.key symbols

yeah its shitty maybe i will make it good someday, right now dont care, dont know it works for me